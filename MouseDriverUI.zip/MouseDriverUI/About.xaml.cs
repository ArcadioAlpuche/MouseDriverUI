﻿using MouseDriverUI.Classes;
using System.Windows;
using System.Windows.Controls;

namespace MouseDriverUI
{
	/// <summary>
	/// Interaction logic for About.xaml
	/// </summary>
	public partial class About : UserControl
	{
		public About()
		{
			InitializeComponent();
		}

		XmlData xmlData = new XmlData();

		private void ResetButton_Click(object sender, RoutedEventArgs e)
		{
			MessageBoxResult result = MessageBox.Show("This operation will reset the entire settings collection to the factory one. Are you sure you want to continue?",
			   "Warning", MessageBoxButton.YesNo);
			switch (result)
			{
				case MessageBoxResult.Yes:
					FactoryReset();
					break;
				case MessageBoxResult.No:
					break;
			}
		}

		private void FactoryReset()
		{
			xmlData.FactoryReset();
			xmlData.ResetComboBoxTemp();
			xmlData.ResetSliderTemp();
		}
	}
}
