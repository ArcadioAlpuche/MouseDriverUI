﻿using MouseDriverUI.Classes;
using System;
using System.Windows.Controls;

namespace MouseDriverUI
{
	/// <summary>
	/// Interaction logic for ButtonWheel.xaml
	/// </summary>
	public partial class ButtonWheel : UserControl
	{
		public ButtonWheel()
		{
			InitializeComponent();
		}

		public event EventHandler ValueChanged;

		XmlData xmlData = new XmlData();
		private void Button_DropDownClosed(object sender, EventArgs e)
		{
			xmlData.FourthClickSelection = FourthClickButton.Text;
			xmlData.FifthClickSelection = FifthClickButton.Text;
			xmlData.PrimaryButtonSelection = LeftClickButton.Text;
			xmlData.SecondaryButtonSelection = RightClickButton.Text;
			xmlData.DoubleClickSelection = MiddleClickButton.Text;
			xmlData.ScrollWheelSelection = ScrollWheel.Text;

			xmlData.UpdateComboBoxValue();
			ValueChanged(this, e);
		}
	}
}
