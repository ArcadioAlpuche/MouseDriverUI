﻿using MouseDriverUI.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MouseDriverUI
{
	/// <summary>
	/// Interaction logic for Motion.xaml
	/// </summary>
	public partial class Motion : UserControl
	{
		public Motion()
		{
			InitializeComponent();
		}

		public event EventHandler ValueChanged;
		XmlData xmlData = new XmlData();

		private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			xmlData.CursorSensitivitySelection = Convert.ToString(SensitivitySlider.Value);
			xmlData.CursorAccelerationSelection = Convert.ToString(AccelerationSlider.Value);
			xmlData.ScrollSpeedSelection = Convert.ToString(ScrollSpeedSlider.Value);
			xmlData.UpdateSliderValue();
			ValueChanged(this, e);
		}
	}
}
