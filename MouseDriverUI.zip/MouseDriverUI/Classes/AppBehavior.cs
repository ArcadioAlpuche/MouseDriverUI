﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace MouseDriverUI.Classes
{
	public class AppBehavior
	{
        // Controls red border on the left of each button when clicked
        public void ButtonHighlight(DockPanel Panel1, DockPanel Panel2, DockPanel Panel3, DockPanel Active)
        {
            Panel1.Visibility = Visibility.Collapsed;
            Panel2.Visibility = Visibility.Collapsed;
            Panel3.Visibility = Visibility.Collapsed;

            Active.Visibility = Visibility.Visible;
        }

        // Animation for user controls when buttons are clicked

        DoubleAnimation DoubleAnimate = new DoubleAnimation();
        public void UserControlSlideIn(Grid grid, DependencyProperty dp)
        {
            DoubleAnimate.From = 0;
            DoubleAnimate.To = 666;
            DoubleAnimate.Duration = new Duration(TimeSpan.FromMilliseconds(200));
            grid.BeginAnimation(dp, DoubleAnimate);
        }
        public void UserControlSlideOut(Grid grid, DependencyProperty dp)
        {
            DoubleAnimate.From = 666;
            DoubleAnimate.To = 0;
            DoubleAnimate.Duration = new Duration(TimeSpan.FromMilliseconds(200));
            grid.BeginAnimation(dp, DoubleAnimate);
        }

        public void HighlightAnimation(DockPanel dockPanel, DependencyProperty dp)
        {
            DoubleAnimate.From = 0;
            DoubleAnimate.To = 100;
            DoubleAnimate.Duration = new Duration(TimeSpan.FromMilliseconds(500));
            dockPanel.BeginAnimation(dp, DoubleAnimate);
        }
    }
}
