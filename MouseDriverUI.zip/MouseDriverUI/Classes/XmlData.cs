﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace MouseDriverUI.Classes
{
	public class XmlData
	{

        //Change root path to save data to XML
        public string rootPath = $@"C:\Users\Angel\source\repos\MouseDriverUI\MouseDriverUI\XmlFiles";

        public string PrimaryButtonSelection;
        public string SecondaryButtonSelection;
        public string DoubleClickSelection;
        public string ScrollWheelClickSelection;
        public string ScrollWheelSelection;
        public string FourthClickSelection;
        public string FifthClickSelection;


        public void IsElementEmpty(XElement tree, string elementName, ref string selection)
        {
            if (selection == null)
            {
                XElement notEntered = tree.Element(elementName);
                notEntered.Remove();
            }
        }
        public void IsElementPresent(XElement elementName, ref string selection)
        {
            if (elementName != null)
            {
                selection = elementName.Value;
            }
            else
            {
                return;
            }
        }

        /*************** Temp XML Files ***************/
        public void UpdateComboBoxValue()
        {
            XElement xmlTreeValues = new XElement("ButtonWheelStringValues",
                new XElement("PrimaryButton", PrimaryButtonSelection),
                new XElement("SecondaryButton", SecondaryButtonSelection),
                new XElement("DoubleClickButton", DoubleClickSelection),
                new XElement("FourthClickButton", FourthClickSelection),
                new XElement("FifthClickButton", FifthClickSelection),
                new XElement("ScrollWheelClick", ScrollWheelClickSelection),
                new XElement("ScrollWheel", ScrollWheelSelection)
                );

            XElement xElementData = XElement.Load($@"{rootPath}\TempButtonWheelXml.xml");
            IEnumerable<XElement> _ButtonWheelStringValues = xElementData.Elements("ButtonWheelStringValues");

            foreach (var Element in _ButtonWheelStringValues)
            {
                IsElementEmpty(xmlTreeValues, "PrimaryButton", ref PrimaryButtonSelection);
                IsElementEmpty(xmlTreeValues, "SecondaryButton", ref SecondaryButtonSelection);
                IsElementEmpty(xmlTreeValues, "DoubleClickButton", ref DoubleClickSelection);
                IsElementEmpty(xmlTreeValues, "FourthClickButton", ref FourthClickSelection);
                IsElementEmpty(xmlTreeValues, "FifthClickButton", ref FifthClickSelection);
                IsElementEmpty(xmlTreeValues, "ScrollWheelClick", ref ScrollWheelClickSelection);
                IsElementEmpty(xmlTreeValues, "ScrollWheel", ref ScrollWheelSelection);
            }


            XDocument xmlDocument = new XDocument(
                    new XDeclaration("1.0", "utf-8", "yes"),
                        new XElement("ArcadioDesigns", xmlTreeValues)
                        );
            xmlDocument.Save($@"{rootPath}\TempButtonWheelXml.xml");
        }

        public string CursorSensitivitySelection;
        public string CursorAccelerationSelection;
        public string CursorDriftSelection;
        public string ScrollSpeedSelection;
        public void UpdateSliderValue()
        {
            XElement xmlTreeValues = new XElement("MotionValues",
                new XElement("CursorSensitivity", CursorSensitivitySelection),
                new XElement("CursorAcceleration", CursorAccelerationSelection),
                new XElement("ScrollSpeed", ScrollSpeedSelection)
                );

            XElement xElementData = XElement.Load($@"{rootPath}\TempMotionXml.xml");
            IEnumerable<XElement> _MotionValues = xElementData.Elements("MotionValues");

            foreach (var item in _MotionValues)
            {
                IsElementEmpty(xmlTreeValues, "CursorSensitivity", ref CursorSensitivitySelection);
                IsElementEmpty(xmlTreeValues, "CursorAcceleration", ref CursorAccelerationSelection);
                IsElementEmpty(xmlTreeValues, "ScrollSpeed", ref ScrollSpeedSelection);
            }

            XDocument xmlDocument = new XDocument(
                    new XDeclaration("1.0", "utf-8", "yes"),
                            new XElement(xmlTreeValues)
                    );
            xmlDocument.Save($@"{rootPath}\TempMotionXml.xml");
        }

        /*************** Apply Button Method ***************/
        public void ApplyButton()
        {
            XElement xElementSlider = XElement.Load($@"{rootPath}\TempButtonWheelXml.xml");
            XElement xElementComboBox = XElement.Load($@"{rootPath}\TempMotionXml.xml");

            xElementSlider.Add(xElementComboBox);
            xElementSlider.Save($@"{rootPath}\MouseXml.xml");
        }

        /*************** Facotry Reset Method ***************/
        public void FactoryReset()
        {
            XDocument xmlDocument = new XDocument(
                        new XDeclaration("1.0", "utf-8", "yes"),
                            new XElement("ArcadioDesigns",
                                new XElement("ButtonWheelStringValues",
                                    new XElement("PrimaryButton", "Primary Click (Left Click)"),
                                    new XElement("SecondaryButton", "Secondary Click (Right Click)"),
                                    new XElement("DoubleClickButton", "Double Click"),
                                    new XElement("FourthClickButton", "Fourth Click (Back)"),
                                    new XElement("FifthClickButton", "Fifth Click (Forward)"),
                                    new XElement("ScrollWheelClick", "Middle Click (Autoscroll)"),
                                    new XElement("ScrollWheel", "Scroll")
                                    ),
                                new XElement("MotionValues",
                                    new XElement("CursorSensitivity", 5),
                                    new XElement("CursorAcceleration", 2),
                                    new XElement("ScrollSpeed", 50)
                                    )
                                )
                            );

            var files = Directory.GetFiles(rootPath, "*.*", SearchOption.AllDirectories);

            foreach (string file in files)
            {
                var savePath = Path.GetFullPath(file);
                xmlDocument.Save(savePath);
            }
        }
        public void ResetComboBoxTemp()
        {
            XDocument xmlDocument = new XDocument(
                    new XDeclaration("1.0", "utf-8", "yes"),
                        new XElement("ButtonAndWheel",
                            new XElement("ButtonWheelStringValues",
                                new XElement("PrimaryButton", "Primary Click (Left Click)"),
                                new XElement("SecondaryButton", "Secondary Click (Right Click)"),
                                new XElement("DoubleClickButton", "Double Click"),
                                new XElement("FourthClickButton", "Fourth Click (Back)"),
                                new XElement("FifthClickButton", "Fifth Click (Forward)"),
                                new XElement("ScrollWheelClick", "Middle Click (Autoscroll)"),
                                new XElement("ScrollWheel", "Scroll")
                                )
                        )
                    );
            xmlDocument.Save($@"{rootPath}\TempButtonWheelXml.xml");
        }
        public void ResetSliderTemp()
        {
            XDocument xmlDocument = new XDocument(
                    new XDeclaration("1.0", "utf-8", "yes"),
                        new XElement("MotionValues",
                            new XElement("CursorSensitivity", 5),
                            new XElement("CursorAcceleration", 2),
                            new XElement("ScrollSpeed", 50)
                            )
                    );
            xmlDocument.Save($@"{rootPath}\TempMotionXml.xml");
        }

        /*************** Load XML Values to UI ***************/
        public void LoadXmlData()
        {
            
            XElement xElementData = XElement.Load($@"{rootPath}\MouseXml.xml");
            IEnumerable<XElement> ButtonWheelData = xElementData.Elements("ButtonWheelStringValues");
            IEnumerable<XElement> MotionData = xElementData.Elements("MotionValues");

            foreach (var MouseSettings in ButtonWheelData)
            {
                XElement primary = MouseSettings.Element("PrimaryButton");
                XElement secondary = MouseSettings.Element("SecondaryButton");
                XElement doubleClick = MouseSettings.Element("DoubleClickButton");
                XElement fourthClick = MouseSettings.Element("FourthClickButton");
                XElement fifthClick = MouseSettings.Element("FifthClickButton");
                XElement scrollWheelClick = MouseSettings.Element("ScrollWheelClick");
                XElement scrollWheel = MouseSettings.Element("ScrollWheel");

                IsElementPresent(primary, ref PrimaryButtonSelection);
                IsElementPresent(secondary, ref SecondaryButtonSelection);
                IsElementPresent(doubleClick, ref DoubleClickSelection);
                IsElementPresent(fourthClick, ref FourthClickSelection);
                IsElementPresent(fifthClick, ref FifthClickSelection);
                IsElementPresent(scrollWheelClick, ref ScrollWheelClickSelection);
                IsElementPresent(scrollWheel, ref ScrollWheelSelection);

            }

            foreach (var MouseSettings in MotionData)
            {
                XElement cursorSensitivity = MouseSettings.Element("CursorSensitivity");
                XElement cursorAcceleration = MouseSettings.Element("CursorAcceleration");
                XElement scrollSpeed = MouseSettings.Element("ScrollSpeed");

                IsElementPresent(cursorSensitivity, ref CursorSensitivitySelection);
                IsElementPresent(cursorAcceleration, ref CursorAccelerationSelection);
                IsElementPresent(scrollSpeed, ref ScrollSpeedSelection);

            }
          

        }
    }
}
