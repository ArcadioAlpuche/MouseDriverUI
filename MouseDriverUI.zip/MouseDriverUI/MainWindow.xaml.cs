﻿using MouseDriverUI.Classes;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace MouseDriverUI
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		AppBehavior behavior = new AppBehavior();

		public MainWindow()
		{
			InitializeComponent();
			behavior.ButtonHighlight(MotionSidepanel, ButtonWheelSidepanel, AboutSidepanel, AboutSidepanel);
			behavior.UserControlSlideIn(GridContainer, WidthProperty);
			SetActiveUserControl(AboutWindow);
		}

		private void TopBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.DragMove();
		}

		private void XButton_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}

		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}

		private void ApplyButton_Click(object sender, RoutedEventArgs e)
		{
			xmlData.ApplyButton();
			ControlButtonDisabled();
		}

		private void OkButton_Click(object sender, RoutedEventArgs e)
		{
			ApplyButton_Click(sender, e);
			this.Close();
		}

		private void ControlButtonDisabled()
		{
			ApplyButton.IsEnabled = false;
			CancelButton.IsEnabled = false;
			CloseButton.Visibility = Visibility.Visible;
			OkButton.Visibility = Visibility.Collapsed;
		}

		// Button event handlers to display user controls
		public void SetActiveUserControl(UserControl control)
		{
			AboutWindow.Visibility = Visibility.Collapsed;
			ButtonWheelWindow.Visibility = Visibility.Collapsed;
			MotionWindow.Visibility = Visibility.Collapsed;

			control.Visibility = Visibility.Visible;
		}

		// Motion button click event
		private void MotionButton_Click(object sender, RoutedEventArgs e)
		{
			SetActiveUserControl(MotionWindow);
			behavior.ButtonHighlight(MotionSidepanel, ButtonWheelSidepanel, AboutSidepanel, MotionSidepanel);
			behavior.UserControlSlideIn(GridContainer, WidthProperty);
			LoadXml();
			ControlButtonDisabled();
		}

		// Button Wheel button click event
		private void ButtonWheelButton_Click(object sender, RoutedEventArgs e)
		{
			SetActiveUserControl(ButtonWheelWindow);
			behavior.ButtonHighlight(MotionSidepanel, ButtonWheelSidepanel, AboutSidepanel, ButtonWheelSidepanel);
			behavior.UserControlSlideIn(GridContainer, WidthProperty);
			LoadXml();
			ControlButtonDisabled();
		}

		// About button click event
		private void AboutButton_Click(object sender, RoutedEventArgs e)
		{
			SetActiveUserControl(AboutWindow);
			behavior.ButtonHighlight(MotionSidepanel, ButtonWheelSidepanel, AboutSidepanel, AboutSidepanel);
			behavior.UserControlSlideIn(GridContainer, WidthProperty);
			ControlButtonDisabled();
		}

		// Load saved settings from XML file
		XmlData xmlData = new XmlData();
		private void LoadXml()
		{
			xmlData.LoadXmlData();

			MotionWindow.SensitivitySlider.Value = Convert.ToDouble(xmlData.CursorSensitivitySelection);
			MotionWindow.AccelerationSlider.Value = Convert.ToDouble(xmlData.CursorAccelerationSelection);
			MotionWindow.ScrollSpeedSlider.Value = Convert.ToDouble(xmlData.ScrollSpeedSelection);

			ButtonWheelWindow.FourthClickButton.Text = xmlData.FourthClickSelection;
			ButtonWheelWindow.FifthClickButton.Text = xmlData.FifthClickSelection;
			ButtonWheelWindow.LeftClickButton.Text = xmlData.PrimaryButtonSelection;
			ButtonWheelWindow.RightClickButton.Text = xmlData.SecondaryButtonSelection;
			ButtonWheelWindow.MiddleClickButton.Text = xmlData.DoubleClickSelection;
			ButtonWheelWindow.ScrollWheel.Text = xmlData.ScrollWheelSelection;
			
		}


		// When values are changed, activate main window buttons
		private void showButtons(object sender, EventArgs e)
		{
			CloseButton.Visibility = Visibility.Collapsed;
			OkButton.Visibility = Visibility.Visible;
			ApplyButton.IsEnabled = true;
			CancelButton.IsEnabled = true;
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			MotionWindow.ValueChanged += new EventHandler(showButtons);
			ButtonWheelWindow.ValueChanged += new EventHandler(showButtons);
		}

		

		
	}
}
